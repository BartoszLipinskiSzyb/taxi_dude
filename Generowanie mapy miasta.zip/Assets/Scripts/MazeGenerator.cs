using System;
using System.ComponentModel;
using System.Linq;
using System.Text;
using UnityEngine;

class MazeGenerator : MonoBehaviour
{
	private char EMPTY = ' ';
	private char ROAD = '#';
	private char CROSSING = 'X';
	private char CONSTRUCTING_ROAD = '@';
	private char TOWN_SQUARE = '*';

    public int mapWidth = 32;
	public int mapHeight = 32;
	public int numberOfNodes = 3;

    public Vector2 townSquareStart = Vector2.zero;
	public Vector2 townSquareEnd = Vector2.zero;

	private int[,] DIRECTIONS = new int[4, 2]{
		{ -1, 0 },
		{ 0, 1 },
		{ 1, 0 },
		{ 0, -1 }
	};
	private int[] shuffled_indices = new int[4] {
		0,1,2,3
	};

    public void Shuffle(int[] array)
    {
        
        int n = array.Count();
        while (n > 1)
        {
            n--;
            int i = UnityEngine.Random.Range(0, 4);
            int temp = array[i];
            array[i] = array[n];
            array[n] = temp;
        }
    }
    private char[,] GenerateMaze()
	{
		char[,] map = new char[mapHeight, mapWidth];
		for (int y = 0; y < mapHeight; ++y)
		{
			for (int x = 0; x < mapWidth; ++x)
			{
				if (x >= townSquareStart.x && x <= townSquareEnd.x && y >= townSquareStart.y && y <= townSquareEnd.y)
				{
					map[y, x] = TOWN_SQUARE;
				}
				else {
                    map[y, x] = EMPTY;
                }
            }
		}

		int[,] crossings = new int[numberOfNodes, 2];
		for (int node_id = 0; node_id < numberOfNodes; ++node_id) { 
			int randomX = UnityEngine.Random.Range(0, mapWidth);
            int randomY = UnityEngine.Random.Range(0, mapHeight);
			
			// prevent putting crossings on already occupied tiles
			if (map[randomY, randomX] != EMPTY) {
				--node_id;
				continue;
			}

			map[randomY, randomX] = CROSSING;
			crossings[node_id, 0] = randomY;
			crossings[node_id, 1] = randomX;
		}

		int[,,] distances = new int[numberOfNodes, mapHeight, mapWidth];
		for (int y = 0; y < mapHeight; ++y) {
            for (int x = 0; x < mapWidth; ++x)
            {
				for (int node_id = 0; node_id < numberOfNodes; ++node_id) {
					distances[node_id, y, x] = 9999999;
				}
			}
        }

        for (int node_id = 0; node_id < numberOfNodes; ++node_id) {
			int myX = crossings[node_id, 1];
			int myY = crossings[node_id, 0];
			distances[node_id, myY, myX] = 0;

			for (int step = 0; step < mapHeight * mapWidth; ++step) {
				for (int y = 0; y < mapHeight; ++y) {
					for (int x = 0; x < mapWidth; ++x) {
						if (distances[node_id, y, x] == step) {
							for (int direction = 0; direction < DIRECTIONS.GetLength(0); ++direction) {
								// Debug.Log("Direction_id " + direction.ToString());
								int nextX = x + DIRECTIONS[direction, 1];
								int nextY = y + DIRECTIONS[direction, 0];

								if (nextX >= 0 && nextX < mapWidth && nextY >= 0 && nextY < mapHeight && (map[nextY, nextX] == EMPTY || map[nextY, nextX] == CROSSING))
								{
									if (distances[node_id, nextY, nextX] > step + 1) {
										// Debug.Log("Setting x=" + nextX.ToString() + ", y=" + nextY.ToString() + " to " + (step + 1).ToString());
                                        distances[node_id, nextY, nextX] = step + 1;
                                    }
                                }
							}
						}
					}
				}
			}

			for (int to_node = 0; to_node < numberOfNodes; ++to_node) {
				if (node_id == to_node) {
					continue;
				}
				int currY = crossings[to_node, 0];
				int currX = crossings[to_node, 1];
				int destY = crossings[node_id, 0];
				int destX = crossings[node_id, 1];

				// Debug.Log("Going from node (" + destX + ", " + destY + ") to (" + currX + ", " + currY + ")");
				bool doWalk = true;
				int distance = distances[node_id, currY, currX];
				for(int step = distance - 1; step > 0 && doWalk; --step)
				{
                    Shuffle(shuffled_indices);
                    for (int d = 0; d < DIRECTIONS.GetLength(0); ++d)
					{
						int direction = shuffled_indices[d];
						if (currX + DIRECTIONS[direction, 1] >= 0 && currX + DIRECTIONS[direction, 1] < mapWidth && currY + DIRECTIONS[direction, 0] >= 0 && currY + DIRECTIONS[direction, 0] < mapHeight)
						{
							if (map[currY + DIRECTIONS[direction, 0], currX + DIRECTIONS[direction, 1]] == ROAD) { 
								doWalk = false;
							}
                            if (distances[node_id, currY + DIRECTIONS[direction, 0], currX + DIRECTIONS[direction, 1]] == step)
                            {
								map[currY + DIRECTIONS[direction, 0], currX + DIRECTIONS[direction, 1]] = CONSTRUCTING_ROAD;
								currY += DIRECTIONS[direction, 0];
								currX += DIRECTIONS[direction, 1];
								break;
                            }
                        }
					}
				}

				for (int y = 0; y < mapHeight; ++y)
				{
					for (int x = 0; x < mapWidth; ++x) {
						if (map[y, x] == CONSTRUCTING_ROAD)
						{
							map[y, x] = ROAD;
						}
					}
				}

			}
		}

		return map;
	}

    private void PrintMaze(char[,] map)
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < map.GetLength(1); i++)
        {
            for (int j = 0; j < map.GetLength(0); j++)
            {
                sb.Append(map[i, j]);
                sb.Append(' ');
            }
            sb.AppendLine();
        }
        Debug.Log(sb.ToString());
    }

    public void Start()
	{
		char[,] map = GenerateMaze();
		PrintMaze(map);
	}
}